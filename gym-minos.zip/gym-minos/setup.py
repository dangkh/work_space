from setuptools import setup

setup(name='gym-minos',
      version='0.5.1',
      install_requires=['gym==0.9.4']
      )
