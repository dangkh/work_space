#!/usr/bin/env python3

import argparse
import gym
import gym_minos
import matplotlib.pyplot as plt

from minos.config.sim_args import parse_sim_args

REPLAY_MODES = ['actions', 'positions']

def run_gym(sim_args):
    env = gym.make('dang-v0')
    env.configure(sim_args)
    print('Running MINOS gym example')
    for i_episode in range(20):
        print('Starting episode %d' % i_episode)
        observation = env.reset()
        done = False
        num_steps = 0
        while num_steps < 100:
            env.render()
            actions = env.action_list()
            # print(actions)
            try:
                mode = int(input('Input:'))
                mode = len(actions)-1 if mode >= len(actions) else mode
            except ValueError:
                print("Not a number")
            action = actions[mode]
            print(actions[mode])
            observation, reward, done = env.step(action)
            num_steps += 1
            

def main():
    parser = argparse.ArgumentParser(description='Interactive interface to Simulator')
    parser.add_argument('--navmap', action='store_true',
                        default=False,
                        help='Use navigation map')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--state_set_file',
                       help='State set file')
    group.add_argument('--replay',
                       help='Load and replay action trace from file')
    group.add_argument('--replay_mode',
                       choices=REPLAY_MODES,
                       default='positions',
                       help='Use actions or positions for replay')
    group.add_argument('--show_goals', action='store_true',
                       default=False,
                       help='show goal observations')

    args = parse_sim_args(parser)
    args.visualize_sensors = True
    run_gym(args)


if __name__ == "__main__":
    main()
