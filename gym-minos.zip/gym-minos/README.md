# Gym wrapper for MINOS

## Installation
```
cd gym
pip install -e .
```

## Uninstall
```
pip uninstall gym_minos
```

## Run demos
```
cd example
./demo.py
```
